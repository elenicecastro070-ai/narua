
package com.narua.rpg;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    String serverIp = "168.222.251.98:5177";
    String discord = "https://discord.gg/kZvjdKcAAK";
    String site = "https://narua-pi.vercel.app";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button play = findViewById(R.id.btnPlay);
        Button discordBtn = findViewById(R.id.btnDiscord);
        Button siteBtn = findViewById(R.id.btnSite);

        play.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("samp://" + serverIp));
            startActivity(i);
        });

        discordBtn.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(discord));
            startActivity(i);
        });

        siteBtn.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(site));
            startActivity(i);
        });
    }
}
